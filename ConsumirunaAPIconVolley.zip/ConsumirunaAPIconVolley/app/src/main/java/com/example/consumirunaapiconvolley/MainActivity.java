package com.example.consumirunaapiconvolley;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Dirección web
    private static final String URL_API = "https://jsonplaceholder.typicode.com/posts";
    private static final String REQUEST_TAG = "JSON_POSTS";

    // Vistas de la pantalla
    private ListView lvTodos;
    private ProgressBar progressBar;
    private TextView tvEstado;
    private TextView tvTitulo;

    // Cola y lista
    private RequestQueue requestQueue;
    private List<Post> listaPosts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicio de pantalla y llamada a la API
        inicializarVistas();
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        consumirApi();
    }

    // Conexión de vistas por ID
    private void inicializarVistas() {
        lvTodos = findViewById(R.id.lvTodos);
        progressBar = findViewById(R.id.progressBar);
        tvEstado = findViewById(R.id.tvEstado);
        tvTitulo = findViewById(R.id.tvTitulo);
    }

    // Estado de carga
    private void mostrarCargando(boolean cargando) {
        if (cargando) {
            progressBar.setVisibility(View.VISIBLE);
            lvTodos.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
            lvTodos.setVisibility(View.VISIBLE);
        }
    }

    // Mensaje de error
    private void mostrarError(String mensaje) {
        progressBar.setVisibility(View.GONE);
        tvEstado.setVisibility(View.VISIBLE);
        tvEstado.setText(mensaje);
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }

    // Revisión fallo
    private void procesarError(VolleyError error) {
        String mensaje = error.getMessage();
        if (mensaje == null || mensaje.isEmpty()) {
            mensaje = "Verifique la conexión a internet.";
        }
        mostrarError(mensaje);
    }

    // Petición a la API
    private void consumirApi() {
        mostrarCargando(true);
        tvEstado.setVisibility(View.GONE);

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                URL_API,
                null,
                response -> {
                    listaPosts.clear();
                    try {
                        // Lectura de datos
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonObject = response.getJSONObject(i);
                            Post post = new Post(
                                    jsonObject.getInt("userId"),
                                    jsonObject.getInt("id"),
                                    jsonObject.getString("title"),
                                    jsonObject.getString("body")
                            );
                            listaPosts.add(post);
                        }

                        // Carga de la lista
                        ArrayAdapter<Post> adapter = new ArrayAdapter<>(
                                this,
                                android.R.layout.simple_list_item_1,
                                listaPosts
                        );
                        lvTodos.setAdapter(adapter);

                        mostrarCargando(false);
                        tvEstado.setVisibility(View.VISIBLE);
                        tvEstado.setText("Se recibieron " + listaPosts.size() + " registros.");

                    } catch (JSONException e) {
                        mostrarError("No fue posible procesar la respuesta.");
                    }
                },
                this::procesarError
        );

        request.setTag(REQUEST_TAG);
        requestQueue.add(request);
    }

    // Cancelación petición
    @Override
    protected void onStop() {
        super.onStop();
        if (requestQueue != null) {
            requestQueue.cancelAll(REQUEST_TAG);
        }
    }
}
