package com.edu.uniempresarial.pokenavigation.data.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class PokemonDetailResponse {

    private String name;
    private int height;
    private int weight;

    @SerializedName("base_experience")
    private int baseExperience;

    private Sprites sprites;
    private List<TypeSlot> types;

    // Getters
    public String getName() {
        return name;
    }

    public int getHeight() {
        return height;
    }

    public int getWeight() {
        return weight;
    }

    public int getBaseExperience() {
        return baseExperience;
    }

    public Sprites getSprites() {
        return sprites;
    }

    public List<TypeSlot> getTypes() {
        return types;
    }

    // --- Clases internas para mapear la imagen oficial y los tipos ---

    // 1. Mapea el objeto "sprites"
    public static class Sprites {
        private Other other;

        public Other getOther() {
            return other;
        }

        public static class Other {
            @SerializedName("official-artwork")
            private OfficialArtwork officialArtwork;

            public OfficialArtwork getOfficialArtwork() {
                return officialArtwork;
            }

            public static class OfficialArtwork {
                @SerializedName("front_default")
                private String frontDefault;

                // URL directa de la imagen oficial
                public String getFrontDefault() {
                    return frontDefault;
                }
            }
        }
    }

    // 2. Mapea la lista de tipos "types"
    public static class TypeSlot {
        private TypeInfo type;

        public TypeInfo getType() {
            return type;
        }

        public static class TypeInfo {
            private String name; // Nombre del tipo (ej: "fire", "water")

            public String getName() {
                return name;
            }
        }
    }
}