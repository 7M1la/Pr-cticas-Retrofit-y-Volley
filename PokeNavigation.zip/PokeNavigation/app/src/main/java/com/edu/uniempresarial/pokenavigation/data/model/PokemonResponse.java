package com.edu.uniempresarial.pokenavigation.data.model;

import java.util.List;

public class PokemonResponse {
    private int count;
    private String next;
    private String previous;
    private List<Pokemon> results;
    public int getCount() {
        return count;
    }
    public List<Pokemon> getResults() {
        return results;
    }
}
// La PokéAPI no retorna directamente una lista. Retorna un objeto que contiene count, next, previous y results. Por eso
//se necesita PokemonResponse
