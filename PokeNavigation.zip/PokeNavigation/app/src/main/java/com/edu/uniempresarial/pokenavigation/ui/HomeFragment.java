package com.edu.uniempresarial.pokenavigation.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.edu.uniempresarial.pokenavigation.R;
import com.edu.uniempresarial.pokenavigation.data.model.Pokemon;
import com.edu.uniempresarial.pokenavigation.data.model.PokemonResponse;
import com.edu.uniempresarial.pokenavigation.data.repository.PokemonRepository;
import com.edu.uniempresarial.pokenavigation.ui.adapter.PokemonAdapter;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.CircularProgressIndicator;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    //Declaración de atributos
    private RecyclerView recyclerPokemon;
    private CircularProgressIndicator progressIndicator;
    private LinearLayout errorContainer;
    private TextView tvError;
    private MaterialButton btnRetry;

    // Herramientas necesarias para manejar la lista y los datos de la API
    private PokemonAdapter adapter;
    private PokemonRepository repository;
    private Call<PokemonResponse> currentCall;

    // Asocia la pantalla (fragment_home.xml) con esta clase
    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    // Este metodo se ejecuta cuando la pantalla ya está creada y lista
    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        // Paso 1: Vincular los botones y campos del archivo XML con el código Java
        recyclerPokemon = view.findViewById(R.id.recyclerPokemon);
        progressIndicator = view.findViewById(R.id.progressIndicator);
        errorContainer = view.findViewById(R.id.errorContainer);
        tvError = view.findViewById(R.id.tvError);
        btnRetry = view.findViewById(R.id.btnRetry);

        // Paso 2: Crear el adaptador (el que dibuja la lista) y definir qué pasa al tocar un elemento
        adapter = new PokemonAdapter(this::mostrarPokemonSeleccionado);

        // Paso 3: Inicializar la clase que se encarga de pedir los datos a internet
        repository = new PokemonRepository();

        // Paso 4: Configurar el RecyclerView para que muestre los elementos en una lista vertical
        recyclerPokemon.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );
        recyclerPokemon.setHasFixedSize(true);
        recyclerPokemon.setAdapter(adapter);

        // Paso 5: Escuchar el clic del botón "Reintentar" por si falla la conexión
        btnRetry.setOnClickListener(v -> cargarPokemon());

        // Paso 6: Solicitar la lista de Pokémon al abrir la pantalla
        cargarPokemon();
    }

    // Metodo principal para realizar la petición a internet
    private void cargarPokemon() {
        // Muestra la barra de carga antes de pedir los datos
        mostrarCargando();

        // Solicita los primeros 30 Pokémon al repositorio
        currentCall = repository.obtenerPokemon(30, 0);

        // Envía la solicitud a internet en segundo plano
        currentCall.enqueue(new Callback<PokemonResponse>() {
            @Override
            public void onResponse(
                    @NonNull Call<PokemonResponse> call,
                    @NonNull Response<PokemonResponse> response
            ) {
                // Si la pantalla ya no existe, ignora el resultado
                if (!isAdded()) {
                    return;
                }

                PokemonResponse body = response.body();

                // Si la API responde bien y trae información
                if (response.isSuccessful()
                        && body != null
                        && body.getResults() != null) {

                    // Pasa la lista de Pokémon al adaptador y cambia la pantalla para mostrar el contenido
                    adapter.actualizarDatos(body.getResults());
                    mostrarContenido();
                } else {
                    // Muestra el mensaje de error si el servidor falló
                    mostrarError(
                            "No fue posible obtener los Pokémon. "
                                    + "Código HTTP: " + response.code()
                    );
                }
            }

            @Override
            public void onFailure(
                    @NonNull Call<PokemonResponse> call,
                    @NonNull Throwable throwable
            ) {
                // Si la petición se canceló o el usuario cambió de pantalla, no hace nada
                if (call.isCanceled() || !isAdded()) {
                    return;
                }

                // Muestra la pantalla de error de conexión (ej. sin internet)
                mostrarError(
                        "Error de conexión. Verifique internet "
                                + "e intente nuevamente."
                );
            }
        });
    }

    // Muestra un mensaje emergente (Toast) cuando la persona toca un Pokémon de la lista
    private void mostrarPokemonSeleccionado(Pokemon pokemon) {
        Toast.makeText(
                requireContext(),
                "Seleccionó: " + pokemon.getName(),
                Toast.LENGTH_SHORT
        ).show();
        //Para abrir el nuevo fragmento
        DetailFragment detailFragment = new DetailFragment();
        Bundle args = new Bundle();
        args.putString("POKEMON_NAME", pokemon.getName());
        detailFragment.setArguments(args);

        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, detailFragment)
                .addToBackStack(null) // Permite volver atrás a la lista principal
                .commit();
    }

    // Estado 1: Muestra la barra de carga y oculta la lista y los errores
    private void mostrarCargando() {
        progressIndicator.setVisibility(View.VISIBLE);
        recyclerPokemon.setVisibility(View.GONE);
        errorContainer.setVisibility(View.GONE);
    }

    // Estado 2: Muestra la lista con los Pokémon y oculta el resto
    private void mostrarContenido() {
        progressIndicator.setVisibility(View.GONE);
        recyclerPokemon.setVisibility(View.VISIBLE);
        errorContainer.setVisibility(View.GONE);
    }

    // Estado 3: Muestra la pantalla con el mensaje de error y el botón de reintentar
    private void mostrarError(String mensaje) {
        progressIndicator.setVisibility(View.GONE);
        recyclerPokemon.setVisibility(View.GONE);
        errorContainer.setVisibility(View.VISIBLE);
        tvError.setText(mensaje);
    }

    // Se ejecuta al salir o cerrar la pantalla para cancelar la descarga si sigue en proceso
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (currentCall != null) {
            currentCall.cancel();
        }
        recyclerPokemon.setAdapter(null);
        super.onDestroyView();
    }
}
//La solicitud se cancela en onDestroyView para evitar que una respuesta intente modificar vistas que ya no