package com.edu.uniempresarial.pokenavigation;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.fragment.app.Fragment;

import com.edu.uniempresarial.pokenavigation.ui.FavoritesFragment;
import com.edu.uniempresarial.pokenavigation.ui.HomeFragment;
import com.edu.uniempresarial.pokenavigation.ui.InfoFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    //Declaración de atributos
    private BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initObjects();
        // Activar el escuchador del menú inferior para cambiar entre pantallas al hacer clic
        configuratBottomNavigation();
    }
    //Metodo que recibe el id del item de la seleccion de opcion en el menú
    private Fragment obtenerFragment(int itemId){
        if (itemId == R.id.navigation_home){
            return new HomeFragment();
        }
        if (itemId == R.id.navigation_favorites){
            return new FavoritesFragment();
        }
        if (itemId == R.id.navigation_info){
            return new InfoFragment();
        }
        return null;
    }

    //Metodo de carga del Fragment (el Fragment es para la navegacion)
    private void cargarFragment (Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .commit();
    }
    //Metodo de configuración de Bottom, aquí se debe saber cual fragment cargar
    private void configuratBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener(menuItem -> {
            Fragment fragment = obtenerFragment(menuItem.getItemId());
            if (fragment == null){
                return false;
            }
            cargarFragment(fragment);
            return true;
        });
    }

    private void initObjects() {
        bottomNavigation = findViewById(R.id.bottomNavigation);
    }
}