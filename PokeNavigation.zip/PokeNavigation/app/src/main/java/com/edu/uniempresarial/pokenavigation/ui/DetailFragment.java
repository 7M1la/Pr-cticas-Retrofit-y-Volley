package com.edu.uniempresarial.pokenavigation.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.edu.uniempresarial.pokenavigation.R;
import com.edu.uniempresarial.pokenavigation.data.model.PokemonDetailResponse;
import com.edu.uniempresarial.pokenavigation.data.repository.PokemonRepository;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.CircularProgressIndicator;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailFragment extends Fragment {

    // Declaración de atributos para la vista XML
    private ImageView imgPokemon;
    private TextView tvName;
    private TextView tvHeight;
    private TextView tvWeight;
    private TextView tvBaseExperience;
    private TextView tvTypes;
    private Button btnFavorite;
    private CircularProgressIndicator progressIndicator;
    private LinearLayout errorContainer;
    private android.widget.ScrollView detailContainer;
    private TextView tvError;
    private Button btnRetry;

    // Herramientas para la petición a la API y manejo del Pokémon actual
    private PokemonRepository repository;
    private Call<PokemonDetailResponse> currentCall;
    private String pokemonName;
    private PokemonDetailResponse currentPokemonDetail;

    // Asocia la pantalla (fragment_detail.xml) con esta clase
    public DetailFragment() {
        super(R.layout.fragment_detail);
    }

    @Override
    public void onViewCreated(
            @NonNull View view,
            @Nullable Bundle savedInstanceState
    ) {
        super.onViewCreated(view, savedInstanceState);

        // Paso 1: Leer el parámetro enviado al abrir el fragmento
        if (getArguments() != null) {
            pokemonName = getArguments().getString("POKEMON_NAME");
        }

        // Paso 2: Vincular los campos y botones del XML
        imgPokemon = view.findViewById(R.id.imgPokemon);
        tvName = view.findViewById(R.id.tvPokemonName);
        tvHeight = view.findViewById(R.id.tvHeight);
        tvWeight = view.findViewById(R.id.tvWeight);
        tvBaseExperience = view.findViewById(R.id.tvBaseExperience);
        btnFavorite = view.findViewById(R.id.btnFavorite);
        
        progressIndicator = view.findViewById(R.id.progressIndicator);
        errorContainer = view.findViewById(R.id.errorContainer);
        detailContainer = view.findViewById(R.id.detailContainer);
        tvError = view.findViewById(R.id.tvError);
        btnRetry = view.findViewById(R.id.btnRetry);

        // Paso 3: Inicializar el repositorio
        repository = new PokemonRepository();

        // Paso 4: Configurar los eventos de clic
        btnRetry.setOnClickListener(v -> cargarDetallePokemon());
        btnFavorite.setOnClickListener(v -> guardarEnFavoritos());

        // Paso 5: Consultar la API si se recibió el nombre del Pokémon
        if (pokemonName != null && !pokemonName.isEmpty()) {
            cargarDetallePokemon();
        } else {
            mostrarError("No se especificó un Pokémon para consultar.");
        }
    }

    // Metodo principal para consultar el endpoint pokemon/{name}
    private void cargarDetallePokemon() {
        mostrarCargando();

        currentCall = repository.obtenerDetallePokemon(pokemonName);

        currentCall.enqueue(new Callback<PokemonDetailResponse>() {
            @Override
            public void onResponse(
                    @NonNull Call<PokemonDetailResponse> call,
                    @NonNull Response<PokemonDetailResponse> response
            ) {
                if (!isAdded()) {
                    return;
                }

                PokemonDetailResponse body = response.body();

                if (response.isSuccessful() && body != null) {
                    currentPokemonDetail = body;
                    pintarDatos(body);
                    mostrarContenido();
                } else {
                    mostrarError(
                            "No fue posible obtener el detalle. "
                                    + "Código HTTP: " + response.code()
                    );
                }
            }

            @Override
            public void onFailure(
                    @NonNull Call<PokemonDetailResponse> call,
                    @NonNull Throwable throwable
            ) {
                if (call.isCanceled() || !isAdded()) {
                    return;
                }

                mostrarError(
                        "Error de conexión. Verifique internet "
                                + "e intente nuevamente."
                );
            }
        });
    }

    // Metodo para asignar los valores obtenidos de la API a las vistas
    private void pintarDatos(PokemonDetailResponse detail) {
        if (detail == null) return;

        // Nombre en mayúsculas
        if (tvName != null && detail.getName() != null) {
            tvName.setText(detail.getName().toUpperCase());
        }

        // Datos del Pokémon
        if (tvHeight != null) {
            tvHeight.setText("Altura: " + detail.getHeight() + " dm");
        }
        if (tvWeight != null) {
            tvWeight.setText("Peso: " + detail.getWeight() + " hg");
        }
        if (tvBaseExperience != null) {
            tvBaseExperience.setText("Exp. Base: " + detail.getBaseExperience());
        }

        // Cargar Tipos en el ChipGroup
        com.google.android.material.chip.ChipGroup chipGroup = requireView().findViewById(R.id.chipGroupTypes);
        if (chipGroup != null && detail.getTypes() != null) {
            chipGroup.removeAllViews(); // Limpia los chips anteriores
            for (PokemonDetailResponse.TypeSlot typeSlot : detail.getTypes()) {
                if (typeSlot.getType() != null) {
                    com.google.android.material.chip.Chip chip = new com.google.android.material.chip.Chip(requireContext());
                    chip.setText(typeSlot.getType().getName().toUpperCase());
                    chipGroup.addView(chip);
                }
            }
        }

        // Cargar la imagen oficial con la librería Glide
        if (detail.getSprites() != null
                && detail.getSprites().getOther() != null
                && detail.getSprites().getOther().getOfficialArtwork() != null) {

            String imageUrl = detail.getSprites().getOther().getOfficialArtwork().getFrontDefault();

            Glide.with(this)
                    .load(imageUrl)
                    .placeholder(R.drawable.baseline_home_24)
                    .into(imgPokemon);
        }
    }

    // Metodo para manejar la acción del botón Favoritos
    private void guardarEnFavoritos() {
        if (currentPokemonDetail != null) {
            // AQUÍ: Integra la lógica con tu SQLite / Room
            Toast.makeText(
                    requireContext(),
                    "Guardado en Favoritos: " + currentPokemonDetail.getName(),
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Estado 1: Muestra la barra de carga y oculta el detalle y el error
    private void mostrarCargando() {
        progressIndicator.setVisibility(View.VISIBLE);
        detailContainer.setVisibility(View.GONE);
        errorContainer.setVisibility(View.GONE);
    }

    // Estado 2: Muestra el contenido del detalle y oculta el resto
    private void mostrarContenido() {
        progressIndicator.setVisibility(View.GONE);
        detailContainer.setVisibility(View.VISIBLE);
        errorContainer.setVisibility(View.GONE);
    }

    // Estado 3: Muestra el contenedor de error
    private void mostrarError(String mensaje) {
        progressIndicator.setVisibility(View.GONE);
        detailContainer.setVisibility(View.GONE);
        errorContainer.setVisibility(View.VISIBLE);
        tvError.setText(mensaje);
    }

    @Override
    public void onDestroyView() {
        if (currentCall != null) {
            currentCall.cancel();
        }
        super.onDestroyView();
    }
}