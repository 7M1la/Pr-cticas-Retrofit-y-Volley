package com.edu.uniempresarial.pokenavigation.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.edu.uniempresarial.pokenavigation.R;
import com.edu.uniempresarial.pokenavigation.data.model.Pokemon;

import java.util.ArrayList;
import java.util.List;

//Este adaptador se encarga de tomar la lista de Pokémon y
// transformarla en las tarjetas visuales que se ven y tocan en la pantalla.
public class PokemonAdapter
        extends RecyclerView.Adapter<PokemonAdapter.PokemonViewHolder>{
    public interface OnPokemonClickListener{
        void onPokemonClick(Pokemon pokemon);
    }
    private final List<Pokemon> pokemonList = new ArrayList<>();
    private final OnPokemonClickListener listener;

    public PokemonAdapter(OnPokemonClickListener listener){
        this.listener = listener;
    }

    //Recibe la lista nueva de Pokémon, borra la lista vieja,
    // guarda la nueva y refresca la pantalla para mostrar los cambios

    public void actualizarDatos (List<Pokemon> nuevosPokemon) {
        pokemonList.clear();
        if (nuevosPokemon != null) { pokemonList.addAll(nuevosPokemon);
        }
        notifyDataSetChanged();
    }

    //Construye el molde visual de la tarjeta individual cargando el diseño XM
    @NonNull
    @Override
    public PokemonViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pokemon, parent, false);
        return new PokemonViewHolder(view);
    }

    //Ubica qué Pokémon va en cada posición (primero, segundo, tercero) y le pasa la información
    // a la tarjeta correspondiente. También le dice al sistema cuántos elementos hay en total
    // para saber cuántas tarjetas dibujar.
    @Override
    public void onBindViewHolder(
            @NonNull PokemonViewHolder holder,
            int position
    ) {
        Pokemon pokemon = pokemonList.get(position);
        holder.bind(pokemon);
    }

    @Override
    public int getItemCount() {
        return pokemonList.size();
    }

    //Gestiona el contenido de cada tarjeta individual Conecta los textos de la interfaz
    // (nombre y URL) con los datos reales del Pokémon y detecta cuando el usuario pulsa la
    // tarjeta para activar la acción programada
    class PokemonViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvPokemonName;
        private final TextView tvPokemonUrl;

        public PokemonViewHolder(@NonNull View itemView) {
            super(itemView);

            tvPokemonName = itemView.findViewById(R.id.tvPokemonName);
            tvPokemonUrl = itemView.findViewById(R.id.tvPokemonUrl);
        }

        public void bind(Pokemon pokemon) {
            tvPokemonName.setText(pokemon.getName());
            tvPokemonUrl.setText(pokemon.getUrl());

            itemView.setOnClickListener(
                    view -> listener.onPokemonClick(pokemon)
            );
        }
    }
}
