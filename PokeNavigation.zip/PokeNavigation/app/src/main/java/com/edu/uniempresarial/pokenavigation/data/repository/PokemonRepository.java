package com.edu.uniempresarial.pokenavigation.data.repository;

import com.edu.uniempresarial.pokenavigation.data.model.PokemonDetailResponse;
import com.edu.uniempresarial.pokenavigation.data.model.PokemonResponse;
import com.edu.uniempresarial.pokenavigation.data.remote.PokeApiService;
import com.edu.uniempresarial.pokenavigation.data.remote.RetrofitClient;

import retrofit2.Call;

public class PokemonRepository {

    private final PokeApiService service;

    public PokemonRepository() {
        service = RetrofitClient.getService();
    }

    public Call<PokemonResponse> obtenerPokemon(
            int limit,
            int offset
    ) {
        return service.getPokemon(limit, offset);
    }

    // Metodo para obtener la información detallada de un Pokémon por su nombre
    public Call<PokemonDetailResponse> obtenerDetallePokemon(String name) {
        return service.obtenerDetallePokemon(name);
    }
}
//El repositorio separa la obtención de datos del Fragment