package com.edu.uniempresarial.pokenavigation.data.model;

public class Pokemon {
    private String name;
    private  String url;

    public String getName(){return name;}
    public String getUrl(){return url;}
}
